import Blender

cube = Blender.Object.Get()[7]


if Blender.Get('curframe') == 1:
	cube.setLocation(-18.0,-4.0,0.0)	
	Blender.Scene.getCurrent().setCurrentCamera(Blender.Object.Get('Camera'))
	print "seta posicao inicial do objeto"


n = cube.getLocation()[0]
curFrame = Blender.Get('curframe')
if curFrame >20 and curFrame < 80:
	n+=0.1
	print "Slow"
	if curFrame >= 20 and curFrame < 30:
		Blender.Scene.getCurrent().setCurrentCamera(Blender.Object.Get('Camera.001'))
	else:
		if curFrame >= 30 and curFrame < 40:
			Blender.Scene.getCurrent().setCurrentCamera(Blender.Object.Get('Camera.002'))
		else:
			if curFrame >= 40 and curFrame < 50:
				Blender.Scene.getCurrent().setCurrentCamera(Blender.Object.Get('Camera.003'))
			else:
				if curFrame >= 50 and curFrame < 60:
					Blender.Scene.getCurrent().setCurrentCamera(Blender.Object.Get('Camera.004'))
				else:
					if curFrame >= 60 and curFrame < 70:
						Blender.Scene.getCurrent().setCurrentCamera(Blender.Object.Get('Camera.005'))
					else:
						if curFrame >= 70:
							Blender.Scene.getCurrent().setCurrentCamera(Blender.Object.Get('Camera.006'))

else:
	if Blender.Get('curframe') >= 80 and Blender.Get('curframe') < 85:
		print "Very FAST"
		n += 1.2
	else:
		n += 1.0
		print "FAST!"
		
cube.setLocation(n,-4.0,0.0)		